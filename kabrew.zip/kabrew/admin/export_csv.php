<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

include '../db.php';

// Set CSV headers
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=KaBrew_Order_Report.csv');

$output = fopen("php://output", "w");

// CSV Column Headers
fputcsv($output, ['Order ID', 'Customer Name', 'Total Price', 'Status', 'Order Date']);

// Get filter parameters
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : "";
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : "";

$query = "SELECT id, customer_name, total_price, status, created_at FROM orders";
$params = [];

if (!empty($startDate) && !empty($endDate)) {
    $query .= " WHERE DATE(created_at) BETWEEN ? AND ?";
    $params[] = $startDate;
    $params[] = $endDate;
}

$query .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param("ss", ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Write data to CSV
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['id'],
        $row['customer_name'],
        $row['total_price'],
        $row['status'],
        date("F d, Y", strtotime($row['created_at']))
    ]);
}

fclose($output);
exit();
?>
