<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Include database connection
include '../db.php';

// Fetch counts for orders, products, and revenue
$totalOrders = $conn->query("SELECT COUNT(*) AS count FROM orders")->fetch_assoc()['count'];
$totalProducts = $conn->query("SELECT COUNT(*) AS count FROM products")->fetch_assoc()['count'];
$totalRevenue = $conn->query("SELECT SUM(total_price) AS revenue FROM orders")->fetch_assoc()['revenue'];
$totalRevenue = $totalRevenue ? $totalRevenue : 0;

// Fetch recent orders
$recentOrders = $conn->query("SELECT id, customer_name, total_price, payment_method, status, created_at FROM orders ORDER BY id DESC LIMIT 5");

// Fetch recent transactions (Only Cash, Gcash, and Orders)
$recentTransactions = $conn->query("
    SELECT t.transaction_id, t.type, t.amount, t.created_at, 
           COALESCE(o.customer_name, 'N/A') AS customer_name, -- Fetch customer_name from orders or default to 'N/A'
           CASE 
               WHEN t.type = 'Order' THEN o.payment_method 
               ELSE t.type 
           END AS payment_method
    FROM transactions t
    LEFT JOIN orders o ON t.transaction_id = CONCAT('ORD-', DATE_FORMAT(o.created_at, '%Y%m%d'), '-', LPAD(o.id, 5, '0'))
    WHERE t.type IN ('Cash', 'Gcash', 'Order')
    ORDER BY t.created_at DESC
    LIMIT 5
");

// Prepare recent transactions list
$recentTransactionsList = [];
while ($row = $recentTransactions->fetch_assoc()) {
    $recentTransactionsList[] = [
        'id' => $row['transaction_id'],
        'customer_name' => $row['customer_name'], // Use the fetched customer_name
        'amount' => $row['amount'],
        'payment_method' => ucfirst($row['payment_method']),
        'created_at' => $row['created_at'],
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .content {
            height: calc(100vh - 50px); /* Adjust this value based on your navbar height */
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Ka-Brew Admin</h2>
        <ul>
            <li><a href="admin_dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_orders.php"><i class="fa-solid fa-receipt"></i> Manage Orders</a></li>
            <li><a href="manage_products.php"><i class="fa-solid fa-boxes-stacked"></i> Manage Products</a></li>
            <li><a href="transactions.php"><i class="fa-solid fa-money-bill-transfer"></i> Transactions</a></li>
            <li><a href="reports.php"><i class="fa-solid fa-file-lines"></i> Reports</a></li>
            <li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="dashboard-overview">
            <div class="card">
                <i class="fa-solid fa-cart-shopping"></i>
                <div>
                    <h3><?php echo $totalOrders; ?></h3>
                    <p>Total Orders</p>
                </div>
            </div>

            <div class="card">
                <i class="fa-solid fa-box-open"></i>
                <div>
                    <h3><?php echo $totalProducts; ?></h3>
                    <p>Products</p>
                </div>
            </div>

            <div class="card">
                <i class="fa-solid fa-peso-sign"></i>
                <div>
                    <h3>₱<?php echo number_format($totalRevenue, 2); ?></h3>
                    <p>Total Revenue</p>
                </div>
            </div>
        </div>

        <!-- Recent Orders -->
        <h3>Recent Orders</h3>
        <table class="orders-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Total Price</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $recentOrders->data_seek(0); // Reset pointer for recent orders ?>
                <?php while ($row = $recentOrders->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td>₱<?php echo number_format($row['total_price'], 2); ?></td>
                        <td><?php echo htmlspecialchars($row['payment_method']); ?></td>
                        <td><span class="status <?php echo strtolower($row['status']); ?>"><?php echo $row['status']; ?></span></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Recent Transactions -->
        <h3>Recent Transactions</h3>
        <table class="transactions-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Total Amount</th>
                    <th>Payment Method</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentTransactionsList as $item): ?>
                    <tr>
                        <td><?php echo $item['id']; ?></td>
                        <td><?php echo htmlspecialchars($item['customer_name']); ?></td>
                        <td>₱<?php echo number_format($item['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($item['payment_method']); ?></td>
                        <td><?php echo date("F j, Y g:i A", strtotime($item['created_at'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>