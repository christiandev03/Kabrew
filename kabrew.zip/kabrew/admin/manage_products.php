<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Include database connection
include '../db.php';

// Fetch all products
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");

// Fetch best-selling product (Matcha Frappe)
$best_seller = $conn->query("SELECT * FROM products WHERE name = 'Matcha Frappe' LIMIT 1");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .content {
            height: calc(100vh - 50px); /* Adjust this value based on your navbar height */
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Ka-Brew Admin</h2>
        <ul>
            <li><a href="admin_dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_orders.php"><i class="fa-solid fa-receipt"></i> Manage Orders</a></li>
            <li><a href="manage_products.php" class="active"><i class="fa-solid fa-boxes-stacked"></i> Manage Products</a></li>
            <li><a href="transactions.php"><i class="fa-solid fa-money-bill-transfer"></i> Transactions</a></li>
            <li><a href="reports.php"><i class="fa-solid fa-file-lines"></i> Reports</a></li>
            <li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2>Manage Products</h2>
        <button onclick="window.location.href='add_product.php'">Add Product</button>

        <!-- Products Table -->
        <table class="products-table">
            <thead>
                <tr>
                    <th>Product ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Size</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $products->fetch_assoc()): ?>
                    <tr id="product-<?php echo $row['id']; ?>">
                        <td><?php echo $row['id']; ?></td>
                        <td><img src="uploads/<?php echo $row['image']; ?>" alt="Product Image" width="50"></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['category']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo $row['size']; ?></td>
                        <td>₱<?php echo number_format($row['price'], 2); ?></td>
                        <td>
                            <button class="edit-btn" onclick="editProduct(<?php echo $row['id']; ?>)">
                                <i class="fa-solid fa-pen"></i> Edit
                            </button>
                            <button class="delete-btn" onclick="deleteProduct(<?php echo $row['id']; ?>)">
                                <i class="fa-solid fa-trash"></i> Delete
                            </button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Best Seller Section -->
        <h3>Best Seller</h3>
        <div class="best-sellers">  
            <?php if ($row = $best_seller->fetch_assoc()): ?>
                <div class="best-seller-card">
                    <img src="uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
                    <h3><?php echo $row['name']; ?></h3>
                    <p>₱<?php echo number_format($row['price'], 2); ?></p>
                </div>      
            <?php endif; ?>
        </div>
    </div>

    <script>
        function editProduct(productId) {
            window.location.href = "edit_product.php?id=" + productId;  
        }

        function deleteProduct(productId) {
            if (confirm("Are you sure you want to delete this product?")) {
                $.ajax({
                    url: "delete_product.php",
                    type: "POST",
                    data: { product_id: productId },
                    success: function(response) {
                        if (response.trim() === "success") {
                            $("#product-" + productId).remove();
                            alert("Product deleted successfully.");
                        } else {
                            alert("Error: " + response);
                        }
                    },
                    error: function() {
                        alert("An error occurred while deleting the product.");
                    }
                });
            }
        }
    </script>
</body>
</html>