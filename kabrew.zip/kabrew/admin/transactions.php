<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Include database connection
include '../db.php';

// Fetch all orders
$orders = $conn->query("SELECT id, customer_name, total_price, payment_method, created_at FROM orders ORDER BY created_at DESC");

// Insert orders into transactions table
while ($row = $orders->fetch_assoc()) {
    $transaction_id = "ORD-" . date("Ymd", strtotime($row['created_at'])) . "-" . str_pad($row['id'], 5, "0", STR_PAD_LEFT);
    $amount = $row['total_price'];
    $type = $row['payment_method']; // Use 'payment_method' as 'type'
    $created_at = $row['created_at'];

    $conn->query("INSERT INTO transactions (transaction_id, amount, type, created_at) 
                  VALUES ('$transaction_id', '$amount', '$type', '$created_at')
                  ON DUPLICATE KEY UPDATE 
                  amount='$amount', type='$type', created_at='$created_at'");
}

// Re-fetch orders for displaying in the table
$orders = $conn->query("SELECT id, customer_name, total_price, payment_method, created_at FROM orders ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .content {
            height: calc(100vh - 50px); /* Adjust this value based on your navbar height */
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Ka-Brew Admin</h2>
        <ul>
            <li><a href="admin_dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_orders.php"><i class="fa-solid fa-receipt"></i> Manage Orders</a></li>
            <li><a href="manage_products.php"><i class="fa-solid fa-boxes-stacked"></i> Manage Products</a></li>
            <li><a href="transactions.php" class="active"><i class="fa-solid fa-money-bill-transfer"></i> Transactions</a></li>
            <li><a href="reports.php"><i class="fa-solid fa-file-lines"></i> Reports</a></li>
            <li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2>Orders</h2>
        <table class="transactions-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Total Amount</th>
                    <th>Payment Method</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo "ORD-" . date("Ymd", strtotime($row['created_at'])) . "-" . str_pad($row['id'], 5, "0", STR_PAD_LEFT); ?></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td>₱<?php echo number_format($row['total_price'], 2); ?></td>
                        <td><?php echo htmlspecialchars($row['payment_method']); ?></td> <!-- Display correct payment method -->
                        <td><?php echo date("F j, Y g:i A", strtotime($row['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>