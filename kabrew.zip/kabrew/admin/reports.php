<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Include database connection
include '../db.php';

// Initialize variables
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : "";
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : "";

// Prepare SQL query with optional filtering
$query = "SELECT id, total_price, created_at FROM orders";
$params = [];
$types = "";

if (!empty($startDate) && !empty($endDate)) {
    $query .= " WHERE DATE(created_at) BETWEEN ? AND ?";
    $params[] = $startDate;
    $params[] = $endDate;
    $types .= "ss";
}

$query .= " ORDER BY created_at DESC";

// Execute the query using prepared statements
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$orderResults = $stmt->get_result();

// Insert filtered data into sales_reports table if not already exists
$insertQuery = "INSERT INTO sales_reports (order_id, total_sales, report_date) 
                SELECT ?, ?, ? FROM DUAL 
                WHERE NOT EXISTS (SELECT 1 FROM sales_reports WHERE order_id = ?)";
$insertStmt = $conn->prepare($insertQuery);

while ($row = $orderResults->fetch_assoc()) {
    $insertStmt->bind_param("idsi", $row['id'], $row['total_price'], $row['created_at'], $row['id']);
    $insertStmt->execute();
}

$insertStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Reports | Ka-Brew Admin</title>
    <link rel="stylesheet" href="admin.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> 
    <style>
        /* Add styles for scrollable table */
        .orders-table-container {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 20px;
        }
        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }
        .orders-table th, .orders-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .orders-table th {
            background-color: #754122;
            color: white;
            font-size: 16px;
        }
        .orders-table tr:hover {
            background-color: #f9f9f9;
        }
    </style>
    <script>
        function printReport() {
            let table = document.getElementById("ordersTable").outerHTML;
            let newWindow = window.open("", "_blank");
            newWindow.document.write(`
                <html>
                <head>
                    <title>Ka-Brew Order Report</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        table { width: 100%; border-collapse: collapse; }
                        th, td { border: 1px solid black; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                    </style>
                </head>
                <body>
                    <h2>Ka-Brew Order Report</h2>
                    ${table}
                    <script>
                        window.onload = function() {
                            window.print();
                            window.close();
                        };
                    <\/script>
                </body>
                </html>
            `);
            newWindow.document.close();
        }

        function exportToCSV() {
            let startDate = document.querySelector('input[name="start_date"]').value;
            let endDate = document.querySelector('input[name="end_date"]').value;
            let url = `export_csv.php?start_date=${startDate}&end_date=${endDate}`;
            window.location.href = url;
        }
    </script>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Ka-Brew Admin</h2>
        <ul>
            <li><a href="admin_dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_orders.php"><i class="fa-solid fa-receipt"></i> Manage Orders</a></li>
            <li><a href="manage_products.php"><i class="fa-solid fa-boxes-stacked"></i> Manage Products</a></li>
            <li><a href="transactions.php"><i class="fa-solid fa-money-bill-transfer"></i> Transactions</a></li>
            <li><a href="reports.php" class="active"><i class="fa-solid fa-file-lines"></i> Reports</a></li>
            <li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2>Order Reports</h2>

        <!-- Filter Form -->
        <form method="GET" class="filter-form">
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>" required>
            
            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>" required>
            
            <button type="submit">Filter</button>
        </form>

        <!-- Print & Export Buttons -->
        <button onclick="printReport()">🖨️ Print Report</button>
        <button onclick="exportToCSV()">📄 Export to CSV</button>

        <!-- Orders Table -->
        <div class="orders-table-container">
            <table id="ordersTable" class="orders-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Total Price</th>
                        <th>Order Date</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    // Fetch data from sales_reports table to display in the report
                    $reportQuery = "SELECT order_id, total_sales, report_date FROM sales_reports ORDER BY report_date DESC";
                    $reportResults = $conn->query($reportQuery);
                    while ($row = $reportResults->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['order_id']); ?></td>
                            <td>₱<?php echo number_format($row['total_sales'], 2); ?></td>
                            <td><?php echo htmlspecialchars(date("F d, Y", strtotime($row['report_date']))); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
