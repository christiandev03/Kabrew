<?php
session_start();

// Ensure only admins can access
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../db.php'; // Ensure a secure connection

// Fetch total orders count
$totalOrders = 0;
$totalOrdersQuery = $conn->query("SELECT COUNT(*) AS count FROM orders");
if ($totalOrdersQuery) {
    $totalOrders = $totalOrdersQuery->fetch_assoc()['count'];
}

// Fetch all orders
$orders = [];
$ordersQuery = $conn->query("SELECT * FROM orders ORDER BY id DESC");
if ($ordersQuery) {
    while ($row = $ordersQuery->fetch_assoc()) {
        $orders[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .content {
            height: calc(100vh - 50px); /* Adjust this value based on your navbar height */
            overflow-y: auto;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Ka-Brew Admin</h2>
        <ul>
            <li><a href="admin_dashboard.php"><i class="fa-solid fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_orders.php" class="active"><i class="fa-solid fa-receipt"></i> Manage Orders</a></li>
            <li><a href="manage_products.php"><i class="fa-solid fa-boxes-stacked"></i> Manage Products</a></li>
            <li><a href="transactions.php"><i class="fa-solid fa-money-bill-transfer"></i> Transactions</a></li>
            <li><a href="reports.php"><i class="fa-solid fa-file-lines"></i> Reports</a></li>
            <li><a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2>Manage Orders</h2>

        <!-- Order Summary -->
        <div class="dashboard-overview">
            <div class="card">
                <i class="fa-solid fa-cart-shopping"></i>
                <div>
                    <h3><?php echo $totalOrders; ?></h3>
                    <p>Total Orders</p>
                </div>
            </div>
        </div>

        <!-- Orders Table -->
        <table class="orders-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Order Details</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($orders)): ?>
                    <?php foreach ($orders as $order): ?>
                        <?php 
                            $orderDetails = json_decode($order['order_details'], true); 
                        ?>
                        <tr id="order-<?php echo htmlspecialchars($order['id']); ?>">
                            <td><?php echo htmlspecialchars($order['id']); ?></td>
                            <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                            <td>
                                <?php if (is_array($orderDetails)): ?>
                                    <ul>
                                        <?php foreach ($orderDetails as $item): ?>
                                            <li>
                                                <?php echo htmlspecialchars($item['quantity']) . "x " . htmlspecialchars($item['name']); ?>
                                                (Size: <?php echo htmlspecialchars($item['size']); ?>, 
                                                Sugar: <?php echo htmlspecialchars($item['sugarLevel']); ?>)
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <?php echo htmlspecialchars($order['order_details']); ?>
                                <?php endif; ?>
                            </td>
                            <td>₱<?php echo number_format($order['total_price'], 2); ?></td>
                            <td>
                                <select class="order-status" data-order-id="<?php echo htmlspecialchars($order['id']); ?>">
                                    <option value="Pending" <?php echo ($order['status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Processing" <?php echo ($order['status'] === 'Processing') ? 'selected' : ''; ?>>Processing</option>
                                    <option value="Completed" <?php echo ($order['status'] === 'Completed') ? 'selected' : ''; ?>>Completed</option>
                                    <option value="Cancelled" <?php echo ($order['status'] === 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </td>
                            <td>
                                <button class="delete-btn" onclick="deleteOrder(<?php echo htmlspecialchars($order['id']); ?>)">
                                    <i class="fa-solid fa-trash"></i> Delete
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">No orders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- JavaScript -->
    <script>
        $(document).ready(function () {
            $(".order-status").change(function () {
                var orderId = $(this).data("order-id");
                var newStatus = $(this).val().trim();

                $.ajax({
                    url: "update_order_status.php",
                    type: "POST",
                    data: { order_id: orderId, status: newStatus },
                    success: function (response) {
                        console.log("Status updated: " + response);
                    }
                });
            });
        });

        function deleteOrder(orderId) {
            if (confirm("Are you sure you want to delete this order?")) {
                $.ajax({
                    url: "delete_order.php",
                    type: "POST",
                    data: { order_id: orderId },
                    success: function (response) {
                        $("#order-" + orderId).remove();
                        console.log("Order deleted: " + response);
                    }
                });
            }
        }
    </script>

</body>
</html>