-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2025 at 01:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ka_brew_ordering`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('Pending','Processing','Completed','Cancelled') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(50) NOT NULL,
  `order_details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `total_price`, `status`, `created_at`, `payment_method`, `order_details`) VALUES
(50, 'customer', 55.00, 'Cancelled', '2025-04-06 10:32:05', 'Cash', '1x Iced Caramel Macchiato (Size: Large, Sugar: No Sugar)'),
(51, 'customer', 55.00, 'Completed', '2025-04-06 10:32:14', 'Cash', '1x Java Chip Frappe (Size: Large, Sugar: 25%)'),
(52, 'customer', 35.00, 'Processing', '2025-04-06 10:32:23', 'Cash', '1x Lemonade (Size: Small, Sugar: No Sugar)'),
(53, 'customer', 55.00, 'Pending', '2025-04-06 10:32:32', 'Cash', '1x Matcha Frappe (Size: Large, Sugar: No Sugar)');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `size` varchar(255) NOT NULL,
  `total_sold` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `category`, `created_at`, `size`, `total_sold`) VALUES
(2, 'Matcha Latte', 'Iced Matcha Drink.', 55.00, '1740539932_matcha_latte.png', 'Non-Coffee Based', '2025-02-23 02:00:46', 'Large', 0),
(3, 'Matcha Frappe', 'Matcha with whip cream.', 55.00, '1740539987_matcha_frappe.png', 'Non-Coffee Based', '2025-02-26 03:19:47', 'Large', 0),
(4, 'Java Chip Frappe', 'Combines milk, and chocolate chips to form a creamy chocolate drink.', 55.00, '1740542119_391a65d8a69644bbb99e97cd035b0ba2-removebg-preview.png', 'Non-Coffee Based', '2025-02-26 03:55:19', 'Large', 0),
(5, 'Lemonade', 'A sweet and heavenly taste of bitter sweet lemonade. ', 50.00, '1740542796_4da665f50a2f4f8628a602bac4ba5c1e-removebg-preview.png', 'Fruit Tea', '2025-02-26 04:03:07', 'Large', 0),
(8, 'Iced Caramel Macchiato', 'Lorem Ipsum.', 55.00, '1743686145_iced_caramel_macchiato.png', 'Coffee Based', '2025-04-03 13:15:45', 'Large', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales_reports`
--

CREATE TABLE `sales_reports` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `total_sales` decimal(10,2) NOT NULL,
  `report_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_reports`
--

INSERT INTO `sales_reports` (`id`, `order_id`, `total_sales`, `report_date`) VALUES
(46, 53, 55.00, '2025-04-06 10:32:32'),
(47, 52, 35.00, '2025-04-06 10:32:23'),
(48, 51, 55.00, '2025-04-06 10:32:14'),
(49, 50, 55.00, '2025-04-06 10:32:05');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `type` enum('Cash','GCash') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `type`, `amount`, `created_at`, `transaction_id`) VALUES
(147, 'Cash', 55.00, '2025-04-06 10:32:32', 'ORD-20250406-00053'),
(148, 'Cash', 35.00, '2025-04-06 10:32:23', 'ORD-20250406-00052'),
(149, 'Cash', 55.00, '2025-04-06 10:32:14', 'ORD-20250406-00051'),
(150, 'Cash', 55.00, '2025-04-06 10:32:05', 'ORD-20250406-00050');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(5, 'admin', '$2y$10$X19VJOihZurGpEZtzPPtaecvY5Afc66iNAb6DWbDbrtZe9rDWDQIi', 'admin'),
(8, 'customer', '$2y$10$iVQl3.x/Vlp3Ll6OpJrY7OmxjaOSSuDSEFqVn9lJRA8OF.Rq2yROq', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_reports`
--
ALTER TABLE `sales_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_id` (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sales_reports`
--
ALTER TABLE `sales_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales_reports`
--
ALTER TABLE `sales_reports`
  ADD CONSTRAINT `sales_reports_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
