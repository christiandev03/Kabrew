<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help</title>
    <link rel="stylesheet" href="../assets/css/help.css"> <!-- Link to external CSS -->
</head>
<body>
    <div class="header">
        <h2>Help & Support</h2>
    </div>
    <div class="container">
        <button class="close-icon" onclick="window.location.href='user_dashboard.php';">&times;</button>
        <h1>Help & Support</h1>
        <p>If you encounter any issues or have questions, we're here to help. Please refer to the contact information below to reach out to our support team.</p>
        <div class="contact-info">
            <p><strong>Email:</strong> kabrew@gmail.com</p>
            <p><strong>Phone:</strong> +63 123 456 7890</p>
            <p><strong>Operating Hours:</strong> Monday to Friday, 9:00 AM - 6:00 PM</p>
        </div>
    </div>
</body>
</html>
