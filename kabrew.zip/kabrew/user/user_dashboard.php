<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

// Include database connection
include '../db.php';

// Get logged-in user's username
$username = $_SESSION['username'];

// Fetch all products with real name, price, and size
$products = $conn->query("SELECT id, name, price, size, image, category FROM products ORDER BY id DESC");

// Fetch distinct product categories
$categories = $conn->query("SELECT DISTINCT category FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ka-Brew - User Dashboard</title>
    <link rel="stylesheet" href="../assets/css/user_dashboard.css"> <!-- Link to external CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo">
                <h2>KA-BREW</h2>
            </div>
            <ul class="menu">
                <li><a href="user_dashboard.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="order_history.php"><i class="fas fa-history"></i> Order History</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="help.php"><i class="fas fa-question-circle"></i> Help</a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        <div class="main-content">
            <div class="menu-bar">
                <button id="toggle-sidebar"><i class="fas fa-bars"></i></button>
                <div class="user-info">
                    <span>Welcome, <?php echo htmlspecialchars($username); ?> <i class="fas fa-user"></i></span>
                </div>
            </div>

            <!-- Category Buttons -->
            <div class="category-buttons">
                <button class="category-btn" data-category="all"><i class="fas fa-th"></i> All</button>
                <?php while ($category = $categories->fetch_assoc()): ?>
                    <button class="category-btn" data-category="<?php echo htmlspecialchars($category['category']); ?>">
                        <i class="fas fa-tag"></i> <?php echo htmlspecialchars(ucwords(str_replace('-', ' ', $category['category']))); ?>
                    </button>
                <?php endwhile; ?>
            </div>

            <!-- Search Bar -->
            <div class="search-container">
                <input type="text" id="search-bar" placeholder="Search products...">
                <button id="search-btn">Search</button>
                <button id="reset-filters-btn">Reset Filters</button>
            </div>

            <!-- Filter and Sort Section -->
            <div class="filter-sort-container">
                <div>
                    <label for="min-price">Min Price:</label>
                    <input type="number" id="min-price" placeholder="₱0" min="0">
                    <label for="max-price">Max Price:</label>
                    <input type="number" id="max-price" placeholder="₱1000" min="0">
                    <button id="filter-price-btn">Filter</button>
                </div>
                <div>
                    <label for="sort-products">Sort By:</label>
                    <select id="sort-products">
                        <option value="name-asc">Name (A-Z)</option>
                        <option value="name-desc">Name (Z-A)</option>
                        <option value="price-asc">Price (Low to High)</option>
                        <option value="price-desc">Price (High to Low)</option>
                    </select>
                </div>
            </div>

            <div class="product-grid">
                <?php while ($row = $products->fetch_assoc()): ?>
                    <div class="product-card" data-category="<?php echo htmlspecialchars($row['category']); ?>">
                        <img src="../admin/uploads/<?php echo $row['image']; ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                        <div class="sizes">
                            <div>Small: ₱<?php echo number_format(35, 2); ?></div>
                            <div>Medium: ₱<?php echo number_format(45, 2); ?></div>
                            <div><?php echo htmlspecialchars(ucfirst($row['size'])); ?>: ₱<?php echo number_format($row['price'], 2); ?></div>
                        </div>
                        <div class="sugar-level">
                            <button class="sugar-btn" data-sugar="No Sugar">0%</button>
                            <button class="sugar-btn" data-sugar="25%">25%</button>
                            <button class="sugar-btn" data-sugar="50%">50%</button>
                            <button class="sugar-btn" data-sugar="75%">75%</button>
                            <button class="sugar-btn" data-sugar="100%">100%</button>
                        </div>
                        <button class="add-to-bag-btn" 
                                data-id="<?php echo $row['id']; ?>"
                                data-name="<?php echo htmlspecialchars($row['name']); ?>" 
                                data-price="35" 
                                data-size="Small">Add Small</button>
                        <button class="add-to-bag-btn" 
                                data-id="<?php echo $row['id']; ?>"
                                data-name="<?php echo htmlspecialchars($row['name']); ?>" 
                                data-price="45" 
                                data-size="Medium">Add Medium</button>
                        <button class="add-to-bag-btn" 
                                data-id="<?php echo $row['id']; ?>"
                                data-name="<?php echo htmlspecialchars($row['name']); ?>" 
                                data-price="<?php echo $row['price']; ?>" 
                                data-size="<?php echo htmlspecialchars($row['size']); ?>">Add <?php echo htmlspecialchars(ucfirst($row['size'])); ?></button>
                    </div>
                <?php endwhile; ?>
            </div>
            
            <div class="order-summary">
                <h2><i class="fas fa-shopping-cart"></i> Order</h2>
                <table>
                    <thead>
                        <tr>
                            <th><i class="fas fa-box"></i> Item</th>
                            <th><i class="fas fa-ruler"></i> Size</th> <!-- Added icon -->
                            <th><i class="fas fa-tint"></i> Sugar Level</th> <!-- Added icon -->
                            <th><i class="fas fa-tag"></i> Price</th>
                            <th><i class="fas fa-sort-numeric-up"></i> Quantity</th>
                            <th><i class="fas fa-money-bill-wave"></i> Payment Method</th> <!-- Added icon -->
                            <th><i class="fas fa-tools"></i> Actions</th>
                        </tr>
                    </thead>
                    <tbody id="order-items">
                        <!-- Order items will be dynamically added here -->
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="6"><strong>Total:</strong></td>
                            <td id="order-total">₱0.00</td>
                        </tr>
                    </tfoot>
                </table>
                <div class="payment-method-container">
                    <strong><i class="fas fa-credit-card"></i> Payment Method:</strong>
                    <ul>
                        <li>
                            <input type="radio" name="payment-method" value="Cash" id="payment-cash" checked>
                            <label for="payment-cash"><i class="fas fa-wallet"></i> Cash</label>
                        </li>
                        <li>
                            <input type="radio" name="payment-method" value="GCash" id="payment-gcash">
                            <label for="payment-gcash"><i class="fas fa-mobile-alt"></i> GCash</label>
                        </li>
                    </ul>
                </div>
                <div class="order-actions">
                    <button><i class="fas fa-check"></i> Confirm Order</button>
                    <button><i class="fas fa-times"></i> Cancel All</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const toggleSidebarButton = document.getElementById('toggle-sidebar');
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        const menuBar = document.querySelector('.menu-bar');
        const paymentMethodRadios = document.querySelectorAll('input[name="payment-method"]');

        toggleSidebarButton.addEventListener('click', () => {
            sidebar.classList.toggle('hidden');
            if (sidebar.classList.contains('hidden')) {
                mainContent.style.marginLeft = '0';
                menuBar.style.left = '0';
            } else {
                mainContent.style.marginLeft = '200px';
                menuBar.style.left = '200px';
            }
        });

        const categoryButtons = document.querySelectorAll('.category-btn');
        const productCards = document.querySelectorAll('.product-card');

        categoryButtons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.getAttribute('data-category');

                productCards.forEach(card => {
                    if (category === 'all' || card.getAttribute('data-category') === category) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });

        const orderItems = document.getElementById('order-items');
        const orderTotal = document.getElementById('order-total');
        let total = 0;

        document.querySelectorAll('.add-to-bag-btn').forEach(button => {
            button.addEventListener('click', () => {
                const name = button.getAttribute('data-name');
                const size = button.getAttribute('data-size');
                const price = parseFloat(button.getAttribute('data-price'));
                const sugarLevel = button.closest('.product-card').querySelector('.sugar-level button.active')?.getAttribute('data-sugar') || 'No Sugar';
                const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value; // Get selected payment method

                let existingRow = document.querySelector(`tr[data-name="${name}"][data-size="${size}"][data-sugar-level="${sugarLevel}"]`);
                if (existingRow) {
                    let quantityCell = existingRow.querySelector('.quantity span');
                    let quantity = parseInt(quantityCell.textContent);
                    quantityCell.textContent = quantity + 1;
                } else {
                    const row = document.createElement('tr');
                    row.setAttribute('data-name', name);
                    row.setAttribute('data-size', size);
                    row.setAttribute('data-sugar-level', sugarLevel);
                    row.innerHTML = `
                        <td>${name}</td>
                        <td>${size}</td>
                        <td>${sugarLevel}</td>
                        <td>₱${price.toFixed(2)}</td>
                        <td class="quantity">
                            <button class="decrease-btn">-</button>
                            <span>1</span>
                            <button class="increase-btn">+</button>
                        </td>
                        <td class="payment-method">${paymentMethod}</td>
                        <td><button class="remove-btn"><i class="fas fa-trash"></i></button></td>
                    `;
                    orderItems.appendChild(row);

                    row.querySelector('.increase-btn').addEventListener('click', () => {
                        const quantitySpan = row.querySelector('.quantity span');
                        let quantity = parseInt(quantitySpan.textContent);
                        quantity += 1;
                        quantitySpan.textContent = quantity;
                        total += price;
                        updateTotal();
                    });

                    row.querySelector('.decrease-btn').addEventListener('click', () => {
                        const quantitySpan = row.querySelector('.quantity span');
                        let quantity = parseInt(quantitySpan.textContent);
                        if (quantity > 1) {
                            quantity -= 1;
                            quantitySpan.textContent = quantity;
                            total -= price;
                            updateTotal();
                        }
                    });

                    row.querySelector('.remove-btn').addEventListener('click', () => {
                        const quantity = parseInt(row.querySelector('.quantity span').textContent);
                        total -= price * quantity;
                        updateTotal();
                        row.remove();
                    });
                }

                total += price;
                updateTotal();
            });
        });

        // Update payment method in all rows when a new payment method is selected
        paymentMethodRadios.forEach(radio => {
            radio.addEventListener('change', () => {
                const selectedPaymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
                document.querySelectorAll('#order-items tr .payment-method').forEach(cell => {
                    cell.textContent = selectedPaymentMethod;
                });
            });
        });

        function updateTotal() {
            orderTotal.textContent = `₱${total.toFixed(2)}`;
        }

        document.querySelector('.order-actions button:first-child').addEventListener('click', () => {
            const orderData = [];
            document.querySelectorAll('#order-items tr').forEach(row => {
                const name = row.getAttribute('data-name');
                const size = row.getAttribute('data-size');
                const sugarLevel = row.getAttribute('data-sugar-level');
                const quantity = parseInt(row.querySelector('.quantity span').textContent);
                const price = parseFloat(row.querySelector('td:nth-child(4)').textContent.replace('₱', ''));
                orderData.push({ name, size, sugarLevel, quantity, price });
            });

            const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;

            if (orderData.length === 0) {
                alert('Your order is empty!');
                return;
            }

            fetch('save_order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orderDetails: orderData, total, paymentMethod })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    alert('Order placed successfully!');
                    orderItems.innerHTML = '';
                    total = 0;
                    updateTotal();
                } else {
                    console.error('Server error:', data.error);
                    alert('Failed to place order. Please try again.');
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                alert('An error occurred while placing the order. Please try again.');
            });
        });

        document.querySelector('.order-actions button:last-child').addEventListener('click', () => {
            if (confirm('Are you sure you want to cancel all items?')) {
                orderItems.innerHTML = '';
                total = 0;
                updateTotal();
            }
        });

        // Filter products by price range
        document.getElementById('filter-price-btn').addEventListener('click', () => {
            const minPrice = parseFloat(document.getElementById('min-price').value) || 0;
            const maxPrice = parseFloat(document.getElementById('max-price').value) || Infinity;

            document.querySelectorAll('.product-card').forEach(card => {
                const price = parseFloat(card.querySelector('.sizes div:last-child').textContent.replace('₱', ''));
                if (price >= minPrice && price <= maxPrice) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });

        // Sort products by name or price
        document.getElementById('sort-products').addEventListener('change', (event) => {
            const sortValue = event.target.value;
            const productGrid = document.querySelector('.product-grid');
            const productCards = Array.from(productGrid.children);

            productCards.sort((a, b) => {
                if (sortValue.includes('name')) {
                    const nameA = a.querySelector('h3').textContent.toLowerCase();
                    const nameB = b.querySelector('h3').textContent.toLowerCase();
                    return sortValue === 'name-asc' ? nameA.localeCompare(nameB) : nameB.localeCompare(nameA);
                } else if (sortValue.includes('price')) {
                    const priceA = parseFloat(a.querySelector('.sizes div:last-child').textContent.replace('₱', ''));
                    const priceB = parseFloat(b.querySelector('.sizes div:last-child').textContent.replace('₱', ''));
                    return sortValue === 'price-asc' ? priceA - priceB : priceB - priceA;
                }
            });

            productGrid.innerHTML = '';
            productCards.forEach(card => productGrid.appendChild(card));
        });

        // Search functionality
        const searchBar = document.getElementById('search-bar');
        const searchBtn = document.getElementById('search-btn');
        const resetFiltersBtn = document.getElementById('reset-filters-btn');

        searchBtn.addEventListener('click', () => {
            const searchTerm = searchBar.value.toLowerCase();
            document.querySelectorAll('.product-card').forEach(card => {
                const productName = card.querySelector('h3').textContent.toLowerCase();
                if (productName.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });

        // Reset filters functionality
        resetFiltersBtn.addEventListener('click', () => {
            searchBar.value = '';
            document.getElementById('min-price').value = '';
            document.getElementById('max-price').value = '';
            document.getElementById('sort-products').value = 'name-asc';
            document.querySelectorAll('.product-card').forEach(card => {
                card.style.display = 'block';
            });
        });

        // Handle sugar level button clicks
        document.querySelectorAll('.product-card').forEach(card => {
            const sugarLevelButtons = card.querySelectorAll('.sugar-level button');
            sugarLevelButtons.forEach(button => {
                button.addEventListener('click', () => {
                    sugarLevelButtons.forEach(btn => btn.classList.remove('active')); // Remove active class from all buttons
                    button.classList.add('active'); // Add active class to the clicked button
                });
            });
        });
    </script>
</body>
</html>