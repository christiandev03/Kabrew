<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

include '../db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['orderDetails'], $data['total'], $data['paymentMethod'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit();
}

$username = $_SESSION['username'];
$orderDetails = $data['orderDetails'];
$total = $data['total'];
$paymentMethod = $data['paymentMethod'];

// Simplify order details format
$simplifiedOrderDetails = array_map(function ($item) {
    return "{$item['quantity']}x {$item['name']} (Size: {$item['size']}, Sugar: {$item['sugarLevel']})";
}, $orderDetails);

$orderDetailsString = implode(', ', $simplifiedOrderDetails);

try {
    $stmt = $conn->prepare("INSERT INTO orders (customer_name, total_price, status, created_at, payment_method, order_details) VALUES (?, ?, 'Pending', NOW(), ?, ?)");
    $stmt->bind_param('sdss', $username, $total, $paymentMethod, $orderDetailsString);
    $stmt->execute();

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
