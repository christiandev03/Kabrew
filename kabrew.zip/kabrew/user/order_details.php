<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

include '../db.php';

if (!isset($_GET['order_id'])) {
    header("Location: order_history.php");
    exit();
}

$orderId = intval($_GET['order_id']);
$username = $_SESSION['username'];

// Fetch order details
$orderInfo = $conn->query("SELECT * FROM orders WHERE id = $orderId AND customer_name = '$username'")->fetch_assoc();

if (!$orderInfo) {
    header("Location: order_history.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link rel="stylesheet" href="../assets/css/order_details.css"> <!-- Link to external CSS -->
</head>
<body>
    <div class="header">Order Details</div>
    <div class="container">
        <h1>Order Summary</h1>
        <p><strong>Customer Name:</strong> <?php echo htmlspecialchars($orderInfo['customer_name']); ?></p>
        <p><strong>Order ID:</strong> <?php echo htmlspecialchars($orderInfo['id']); ?></p>
        <p><strong>Date:</strong> <?php echo htmlspecialchars($orderInfo['created_at']); ?></p>
        <p><strong>Total Price:</strong> ₱<?php echo number_format($orderInfo['total_price'], 2); ?></p>

        <h2>Order Items</h2>
        <?php if (!empty($orderInfo['order_details'])): ?>
            <ul>
                <?php 
                // Split the order_details string into individual items
                $orderDetails = explode("\n", $orderInfo['order_details']);
                foreach ($orderDetails as $item): 
                    if (trim($item) === '') continue; // Skip empty lines
                ?>
                    <li><?php echo htmlspecialchars($item); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No items found in this order.</p>
        <?php endif; ?>

        <a href="order_history.php" class="close-btn">Back to Order History</a>
    </div>
</body>
</html>
