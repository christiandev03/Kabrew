<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

include '../db.php';

$username = $_SESSION['username'];

// Fetch order history for the logged-in user
$orderHistory = $conn->query("SELECT * FROM orders WHERE customer_name = '$username' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link rel="stylesheet" href="../assets/css/order_history.css"> <!-- Link to external CSS -->
</head>
<body>
    <div class="header">Order History</div>
    <div class="container">
        <h1>Your Orders</h1>
        <?php if ($orderHistory->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer Name</th> <!-- Added column for customer name -->
                        <th>Date</th>
                        <th>Total</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = $orderHistory->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['id']); ?></td>
                            <td><?php echo htmlspecialchars($order['customer_name']); ?></td> <!-- Display customer name -->
                            <td><?php echo htmlspecialchars($order['created_at']); ?></td>
                            <td>₱<?php echo number_format($order['total_price'], 2); ?></td>
                            <td><a href="order_details.php?order_id=<?php echo $order['id']; ?>" class="view-btn">View</a></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-orders">You have no order history.</p>
        <?php endif; ?>
        <a href="user_dashboard.php" class="close-btn">Close</a>
    </div>
</body>
</html>
